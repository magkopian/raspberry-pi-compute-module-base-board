Filename                        Description
=============================================================

compute_module-B.Cu.gbl          Bottom Copper Layer

compute_module-In1.Cu.g2         Inner Copper Layer 1

compute_module-In2.Cu.g3		 Inner Copper Layer 2

compute_module-F.Cu.gtl          Front Copper Layer

compute_module-F.Mask.gts        Front Soldermask

compute_module-B.Mask.gbs        Bottom Soldermask

compute_module-F.SilkS.gto       Front Silkscreen

compute_module-B.SilkS.gbo       Bottom Silkscreen

compute_module-Edge.Cuts.gm1     Mechanical Layer (Board Outline)

compute_module.drl               Drill File
